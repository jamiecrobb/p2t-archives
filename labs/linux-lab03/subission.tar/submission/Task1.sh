#! /bin/bash

# Create three directories: data, data/processed, docs

mkdir -p data data/processed docs